#! /usr/bin/bash
docker compose -f blinky-modbus-tray.yaml down


