#!/bin/bash
docker restart blinky-box-docker-mosquitto-1
exit 0


