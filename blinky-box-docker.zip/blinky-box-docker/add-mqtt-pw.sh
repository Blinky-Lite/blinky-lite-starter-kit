#!/bin/bash
docker exec blinky-box-docker-mosquitto-1 mosquitto_passwd -b /mqtt-auth/pwfile $1 $2
docker restart blinky-box-docker-mosquitto-1
exit 0


