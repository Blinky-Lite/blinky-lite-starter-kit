#! /usr/bin/bash
docker compose -f blinky-box.yaml down


